# Diccionario ampliado — estado del trabajo

## Qué hay aquí
- `trad/lote_*.json` — entradas ya traducidas al español (acumulativo)
- `build/merge_dicc.py` — inserta los lotes en index.html
- `build/qa_nombres.py` — valida que cada nombre propio exista en la RV1909
- `build/test.js` — pruebas de regresión de toda la app
- `src/easton_en.json` — las 3.962 entradas de Easton en inglés (fuente)
- `src/easton_cortas.json` — orden de trabajo: las 2.294 entradas cortas
- `src/easton_orden.json` — orden por importancia
- `src/index_base.html` — base intacta (con sermones) sobre la que se construye

## Para continuar
1. `python3 -I build/merge_dicc.py`   → reconstruye index.html
2. `python3 -I build/qa_nombres.py`   → revisa los nombres propios
3. `node build/test.js`               → pruebas

## Formato de un lote
{"Término español": {"k":"EnglishKey", "d":"definición en español"}}
La clave "k" sirve para recuperar automáticamente las referencias bíblicas.

## Fuente y licencia
Easton's Bible Dictionary (M.G. Easton, 1897) — dominio público.
Dataset: github.com/neuu-org/bible-dictionary-dataset (CC BY 4.0).
La traducción al español es obra propia.
